#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <locale.h>
#include <time.h> 
#include <string.h>
#include <sstream>
#include <Windows.h>
class Protect {
    using namespace std;
    static bool name(string s) {
        string s1 = "";
        for (int i = 0; i < (int)s.size(); i++) {
            if (s[i] != ' ')
                s1 += s[i];
        }
        regex re("[�-��-�]*");
        if (regex_match(s1, re)) {
            return true;
        }
        else {
            return false;
        }

    };
    static bool height(string s) {
        string s1 = "";
        for (int i = 0; i < (int)s.size(); i++) {
            if (s[i] != ' ')
                s1 += s[i];
        }
        stringstream geek(s1);
        int x = 0;
        geek >> x;
        if (x >= 140 && x <= 260) {
            return true;
        }
        else {
            return false;
        }
    };
    static bool weight(string s) {
        string s1 = "";
        for (int i = 0; i < (int)s.size(); i++) {
            if (s[i] != ' ')
                s1 += s[i];
        }
        stringstream geek(s1);
        int x = 0;
        geek >> x;
        if (x >= 30 && x <= 200) {
            return true;
        }
        else {
            return false;
        }
    };
    static bool rate(string s) {
        string s1 = "";
        for (int i = 0; i < (int)s.size(); i++) {
            if (s[i] != ' ')
                s1 += s[i];
        }
        stringstream geek(s1);
        int x = 0;
        geek >> x;
        if (x >= 0 && x <= 100) {
            return true;
        }
        else {
            return false;
        }
    };
}
 