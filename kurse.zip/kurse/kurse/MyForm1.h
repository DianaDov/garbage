#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <locale.h>
#include <time.h> 
#include <string>
#include <regex>
#include <sstream>
#include <Windows.h>
#include "MyForm2.h"
namespace kurse {

	using namespace System;
	using namespace System::Text::RegularExpressions;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	/// <summary>
	/// ������ ��� MyForm1
	/// </summary>
	public ref class MyForm1 : public System::Windows::Forms::Form
	{
	public:
		MyForm1(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}
		static bool name(string s) {
			string s1 = "";
			for (int i = 0; i < (int)s.size(); i++) {
				if (s[i] != ' ')
					s1 += s[i];
			}
			regex re("[�-��-�]*");
			if (regex_match(s1, re)) {
				return true;
			}
			else {
				return false;
			}

		};

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	public: System::Windows::Forms::TextBox^ login;
	private:


	private: System::Windows::Forms::Label^ label3;
	public: System::Windows::Forms::TextBox^ password;
	private:








	private: System::Windows::Forms::Button^ button1;
	public: System::Windows::Forms::TextBox^ password2;
	private:


	private: System::Windows::Forms::Label^ label4;
	protected:

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>

		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->login = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->password = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->password2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(181, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(192, 24);
			this->label1->TabIndex = 0;
			this->label1->Text = L"����������� ������";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm1::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(93, 61);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(50, 18);
			this->label2->TabIndex = 1;
			this->label2->Text = L"�����";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm1::label2_Click);
			// 
			// login
			// 
			this->login->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F));
			this->login->Location = System::Drawing::Point(171, 59);
			this->login->Name = L"login";
			this->login->Size = System::Drawing::Size(184, 23);
			this->login->TabIndex = 2;
			this->login->TextChanged += gcnew System::EventHandler(this, &MyForm1::textBox1_TextChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(93, 110);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(61, 18);
			this->label3->TabIndex = 3;
			this->label3->Text = L"������";
			// 
			// password
			// 
			this->password->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F));
			this->password->Location = System::Drawing::Point(171, 108);
			this->password->Name = L"password";
			this->password->Size = System::Drawing::Size(184, 23);
			this->password->TabIndex = 4;
			this->password->TextChanged += gcnew System::EventHandler(this, &MyForm1::password_TextChanged);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(350, 180);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(116, 35);
			this->button1->TabIndex = 11;
			this->button1->Text = L"������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm1::button1_Click);
			// 
			// password2
			// 
			this->password2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F));
			this->password2->Location = System::Drawing::Point(171, 151);
			this->password2->Name = L"password2";
			this->password2->Size = System::Drawing::Size(184, 23);
			this->password2->TabIndex = 12;
			this->password2->TextChanged += gcnew System::EventHandler(this, &MyForm1::textBox3_TextChanged);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(6, 153);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(137, 18);
			this->label4->TabIndex = 13;
			this->label4->Text = L"��������� ������";
			this->label4->Click += gcnew System::EventHandler(this, &MyForm1::label4_Click);
			// 
			// MyForm1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(478, 227);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->password2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->password);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->login);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm1";
			this->Text = L"MyForm1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
		   //������
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		bool fl = true;
		String^ stroka = login->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		login->Text = stroka;
		String^ stroka1 = password->Text;
		stroka1 = Regex::Replace(stroka1, "\\s+", "");
		password->Text = stroka1;
		String^ stroka2 = password2->Text;
		stroka2 = Regex::Replace(stroka2, "\\s+", "");
		password2->Text = stroka2;
		if (String::Compare(this->password->Text, this->password2->Text) != 0 || this->password->Text == "" || this->password2->Text == "" || this->login->Text == "") MessageBox::Show("��������� ��������� ������", "���������");
		else {
			System::IO::StreamReader^ stream = System::IO::File::OpenText("F:\\c++\\kurse\\pass.txt");
			String^ line;
			String^ li = this->login->Text + " " + this->password->Text;
			int count = 0;
			while ((line = stream->ReadLine()) ) {
				count++;
				if (String::Compare(li, line) == 0) {
					MessageBox::Show("����� ����� � ������ ��� ����������\n���������", "���������");
					fl = false;
					break;
				}
				else continue;
			}
			delete (IDisposable^)stream;
			if (fl == true && count==0) {
				System::IO::StreamWriter^ fp = System::IO::File::CreateText("F:\\c++\\kurse\\pass.txt");
				fp->WriteLine(this->login->Text + " " + this->password->Text);
				fp->Close();
				MyForm2^ f2 = gcnew MyForm2();
				f2->Show();
				this->Close();
			}
			if (fl == true && count != 0) {
				System::IO::StreamWriter^ fp = gcnew System::IO::StreamWriter("F:\\c++\\kurse\\pass.txt", true);
				fp->WriteLine(this->login->Text + " " + this->password->Text);
				fp->Close();
				MyForm2^ f2 = gcnew MyForm2();
				f2->Show();
				this->Close();
			}
		}
	}
	private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox3_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void password_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
};
}
