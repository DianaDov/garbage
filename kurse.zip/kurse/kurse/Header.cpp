#include "Header.h"
void Player::setName(String^ name2) { name = name2; }
String^ Player::getName() { return name; }

void Player::setSurname(String^ surname2) { surname = surname2; }
String^ Player::getSurname() { return surname; }

void Player::setWeight(String^ weight2) { weight = weight2; }
String^ Player::getWeight() { return weight; }

void Player::setHeight(String^ height2) { height = height2; }
String^ Player::getHeight() { return height; }

void Player::setRate(String^ rate2) { rate = rate2; }
String^ Player::getRate() { return rate; }
String^ Player::adding()
{

	return (name + " " + surname + " " + height + " " + weight +" "+ rate);
}
//void Player::setFlag(bool flag2) { flag = flag2; }
//bool Player::getFlag() { return flag; }

