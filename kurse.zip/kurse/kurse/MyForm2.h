#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <locale.h>
#include <time.h> 
#include <string.h>
#include <regex>
#include <list>
#include <algorithm>
#include <Windows.h>
#include <windows.h>
#include "Header.h"
#include "Header1.h"
#include "MyForm3.h"
namespace kurse {
	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Text::RegularExpressions;
	using namespace System::IO;
	/// <summary>
	/// ������ ��� MyForm2
	/// </summary>

	public ref class MyForm2 : public System::Windows::Forms::Form
	{

	public:
		
	public: System::Windows::Forms::Button^ button12;
	public: System::Windows::Forms::TextBox^ someteam2;



	public: System::Windows::Forms::TextBox^ someresult;

	public: System::Windows::Forms::TextBox^ someteam1;


	public:


	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Label^ label13;
	public:
		static Generic::List<Player^>^ list = gcnew Generic::List<Player^>();
	public: System::Windows::Forms::Button^ button13;
	public: System::Windows::Forms::Button^ button14;
	public: System::Windows::Forms::Button^ button15;
	private: System::Windows::Forms::Label^ label14;
	public:
	public: System::Windows::Forms::TextBox^ someteam21;
	private:
	public: System::Windows::Forms::TextBox^ someresult1;
	public: System::Windows::Forms::TextBox^ someteam11;
	private: System::Windows::Forms::Label^ label15;
	public:
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::Button^ button16;
	public: System::Windows::Forms::Label^ pic3;
	public: System::Windows::Forms::Label^ pic2;
	private:

	public: System::Windows::Forms::Label^ pic1;
	public: System::Windows::Forms::Label^ eagles;
	private: System::Windows::Forms::Button^ statka;
	private: System::Windows::Forms::Button^ clear;
	private: System::Windows::Forms::Button^ button17;
	public:

	public:

		static Generic::List<Play^>^ list1 = gcnew Generic::List<Play^>();

		MyForm2(void)
		{
			
			InitializeComponent();

			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::ContextMenuStrip^ contextMenuStrip1;
	protected:
	public: System::Windows::Forms::TabControl^ tabControl1;
	private:
	public: System::Windows::Forms::TabPage^ tabPage1;
	public: System::Windows::Forms::TabPage^ tabPage2;
	public: System::Windows::Forms::TabPage^ tabPage3;
	public: System::Windows::Forms::TabPage^ tabPage4;

	public:


	private: System::ComponentModel::BackgroundWorker^ backgroundWorker1;


	private:



	public: System::Windows::Forms::DataGridView^ table1;

	public:


	public:





	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	public: System::Windows::Forms::TextBox^ SomeName;
	private:

	public: System::Windows::Forms::TextBox^ SomeSurname;
	public: System::Windows::Forms::TextBox^ SomeHeight;
	public: System::Windows::Forms::TextBox^ SomeWeight;
	public: System::Windows::Forms::TextBox^ SomeRate;
	private:





	public: System::Windows::Forms::Button^ ok;

	public:





	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::DataGridViewCheckBoxColumn^ CheckBox;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ name;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ surname;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ height;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ weight;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ rate;
	private: System::Windows::Forms::TabPage^ tabPage5;
	public: System::Windows::Forms::Button^ button4;
	private:
	public: System::Windows::Forms::Button^ button3;
	public: System::Windows::Forms::Button^ button2;
	public: System::Windows::Forms::TextBox^ rate2;

	public: System::Windows::Forms::TextBox^ weight2;

	public: System::Windows::Forms::TextBox^ height2;

	public: System::Windows::Forms::TextBox^ surname2;

	public: System::Windows::Forms::TextBox^ name2;

	private: System::Windows::Forms::Label^ label6;
	public:
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button5;
	public: System::Windows::Forms::ComboBox^ comboBox1;
	private:

	private: System::Windows::Forms::Button^ button7;
	private: System::Windows::Forms::ColorDialog^ colorDialog1;
	public: System::Windows::Forms::TextBox^ poisk1;
	private:
	public: System::Windows::Forms::ComboBox^ comboBox2;
	private: System::Windows::Forms::Button^ poisk;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::Label^ label11;
	public: System::Windows::Forms::ComboBox^ comboBox3;
	public: System::Windows::Forms::TextBox^ to;
	private:

	public: System::Windows::Forms::TextBox^ from;

	private: System::Windows::Forms::Button^ button8;
	public: System::Windows::Forms::PictureBox^ picture1;
public: System::Windows::Forms::PictureBox^ picture2;



	private:


	private:

	public: System::Windows::Forms::PictureBox^ picture3;
	private: System::Windows::Forms::Button^ button9;
	public:
	private: System::Windows::Forms::Button^ button10;
	private: System::Windows::Forms::Button^ button11;
	public: System::Windows::Forms::DataGridView^ table2;
	private:


	private: System::Windows::Forms::DataGridViewCheckBoxColumn^ CheckBox1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ team1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ result;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ team2;





	public:
	public:

	private:
	public:

	public:

	public:
	private:
	public:
	private:

	public:

	public:
	private:



	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm2::typeid));
			this->contextMenuStrip1 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->to = (gcnew System::Windows::Forms::TextBox());
			this->from = (gcnew System::Windows::Forms::TextBox());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->poisk1 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->poisk = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->table1 = (gcnew System::Windows::Forms::DataGridView());
			this->CheckBox = (gcnew System::Windows::Forms::DataGridViewCheckBoxColumn());
			this->name = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->surname = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->height = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->weight = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->rate = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->clear = (gcnew System::Windows::Forms::Button());
			this->statka = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->table2 = (gcnew System::Windows::Forms::DataGridView());
			this->CheckBox1 = (gcnew System::Windows::Forms::DataGridViewCheckBoxColumn());
			this->team1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->result = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->team2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->eagles = (gcnew System::Windows::Forms::Label());
			this->pic2 = (gcnew System::Windows::Forms::Label());
			this->pic1 = (gcnew System::Windows::Forms::Label());
			this->pic3 = (gcnew System::Windows::Forms::Label());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->picture1 = (gcnew System::Windows::Forms::PictureBox());
			this->picture2 = (gcnew System::Windows::Forms::PictureBox());
			this->picture3 = (gcnew System::Windows::Forms::PictureBox());
			this->tabPage4 = (gcnew System::Windows::Forms::TabPage());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->someteam2 = (gcnew System::Windows::Forms::TextBox());
			this->someresult = (gcnew System::Windows::Forms::TextBox());
			this->someteam1 = (gcnew System::Windows::Forms::TextBox());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->ok = (gcnew System::Windows::Forms::Button());
			this->SomeRate = (gcnew System::Windows::Forms::TextBox());
			this->SomeWeight = (gcnew System::Windows::Forms::TextBox());
			this->SomeHeight = (gcnew System::Windows::Forms::TextBox());
			this->SomeSurname = (gcnew System::Windows::Forms::TextBox());
			this->SomeName = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->tabPage5 = (gcnew System::Windows::Forms::TabPage());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->someteam21 = (gcnew System::Windows::Forms::TextBox());
			this->someresult1 = (gcnew System::Windows::Forms::TextBox());
			this->someteam11 = (gcnew System::Windows::Forms::TextBox());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->rate2 = (gcnew System::Windows::Forms::TextBox());
			this->weight2 = (gcnew System::Windows::Forms::TextBox());
			this->height2 = (gcnew System::Windows::Forms::TextBox());
			this->surname2 = (gcnew System::Windows::Forms::TextBox());
			this->name2 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->colorDialog1 = (gcnew System::Windows::Forms::ColorDialog());
			this->tabControl1->SuspendLayout();
			this->tabPage1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->table1))->BeginInit();
			this->tabPage2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->table2))->BeginInit();
			this->tabPage3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture3))->BeginInit();
			this->tabPage4->SuspendLayout();
			this->tabPage5->SuspendLayout();
			this->SuspendLayout();
			// 
			// contextMenuStrip1
			// 
			this->contextMenuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->contextMenuStrip1->Name = L"contextMenuStrip1";
			this->contextMenuStrip1->Size = System::Drawing::Size(61, 4);
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage3);
			this->tabControl1->Controls->Add(this->tabPage4);
			this->tabControl1->Controls->Add(this->tabPage5);
			this->tabControl1->Location = System::Drawing::Point(2, 0);
			this->tabControl1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(767, 411);
			this->tabControl1->TabIndex = 2;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->button17);
			this->tabPage1->Controls->Add(this->label12);
			this->tabPage1->Controls->Add(this->label11);
			this->tabPage1->Controls->Add(this->comboBox3);
			this->tabPage1->Controls->Add(this->to);
			this->tabPage1->Controls->Add(this->from);
			this->tabPage1->Controls->Add(this->button8);
			this->tabPage1->Controls->Add(this->poisk1);
			this->tabPage1->Controls->Add(this->comboBox2);
			this->tabPage1->Controls->Add(this->poisk);
			this->tabPage1->Controls->Add(this->comboBox1);
			this->tabPage1->Controls->Add(this->button7);
			this->tabPage1->Controls->Add(this->button6);
			this->tabPage1->Controls->Add(this->button5);
			this->tabPage1->Controls->Add(this->button1);
			this->tabPage1->Controls->Add(this->table1);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage1->Size = System::Drawing::Size(759, 385);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"������";
			this->tabPage1->UseVisualStyleBackColor = true;
			this->tabPage1->Click += gcnew System::EventHandler(this, &MyForm2::tabPage1_Click);
			// 
			// button17
			// 
			this->button17->Location = System::Drawing::Point(620, 244);
			this->button17->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(83, 24);
			this->button17->TabIndex = 18;
			this->button17->Text = L"�������";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm2::button17_Click);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(368, 290);
			this->label12->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(19, 13);
			this->label12->TabIndex = 17;
			this->label12->Text = L"��";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(241, 290);
			this->label11->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(18, 13);
			this->label11->TabIndex = 16;
			this->label11->Text = L"��";
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"����", L"���", L"�������" });
			this->comboBox3->Location = System::Drawing::Point(269, 273);
			this->comboBox3->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(84, 21);
			this->comboBox3->TabIndex = 15;
			// 
			// to
			// 
			this->to->Location = System::Drawing::Point(340, 306);
			this->to->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->to->Name = L"to";
			this->to->Size = System::Drawing::Size(46, 20);
			this->to->TabIndex = 14;
			// 
			// from
			// 
			this->from->Location = System::Drawing::Point(236, 306);
			this->from->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->from->Name = L"from";
			this->from->Size = System::Drawing::Size(46, 20);
			this->from->TabIndex = 13;
			this->from->TextChanged += gcnew System::EventHandler(this, &MyForm2::textBox1_TextChanged_2);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(269, 244);
			this->button8->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(83, 24);
			this->button8->TabIndex = 12;
			this->button8->Text = L"�����";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm2::button8_Click);
			// 
			// poisk1
			// 
			this->poisk1->Location = System::Drawing::Point(22, 306);
			this->poisk1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->poisk1->Name = L"poisk1";
			this->poisk1->Size = System::Drawing::Size(84, 20);
			this->poisk1->TabIndex = 11;
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"���", L"�������" });
			this->comboBox2->Location = System::Drawing::Point(22, 273);
			this->comboBox2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(84, 21);
			this->comboBox2->TabIndex = 10;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm2::comboBox2_SelectedIndexChanged);
			// 
			// poisk
			// 
			this->poisk->Location = System::Drawing::Point(22, 244);
			this->poisk->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->poisk->Name = L"poisk";
			this->poisk->Size = System::Drawing::Size(83, 24);
			this->poisk->TabIndex = 9;
			this->poisk->Text = L"�����";
			this->poisk->UseVisualStyleBackColor = true;
			this->poisk->Click += gcnew System::EventHandler(this, &MyForm2::poisk_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(5) { L"���", L"�������", L"����", L"���", L"�������" });
			this->comboBox1->Location = System::Drawing::Point(620, 151);
			this->comboBox1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(84, 21);
			this->comboBox1->TabIndex = 8;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm2::comboBox1_SelectedIndexChanged);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(620, 122);
			this->button7->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(83, 24);
			this->button7->TabIndex = 7;
			this->button7->Text = L"����������";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm2::button7_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(620, 93);
			this->button6->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(83, 24);
			this->button6->TabIndex = 6;
			this->button6->Text = L"��������";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm2::button6_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(620, 63);
			this->button5->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(83, 24);
			this->button5->TabIndex = 5;
			this->button5->Text = L"������";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm2::button5_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(620, 34);
			this->button1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(83, 24);
			this->button1->TabIndex = 4;
			this->button1->Text = L"�������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm2::button1_Click);
			// 
			// table1
			// 
			this->table1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->table1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(6) {
				this->CheckBox, this->name,
					this->surname, this->height, this->weight, this->rate
			});
			this->table1->Location = System::Drawing::Point(2, 5);
			this->table1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->table1->Name = L"table1";
			this->table1->RowHeadersWidth = 51;
			this->table1->RowTemplate->Height = 24;
			this->table1->Size = System::Drawing::Size(603, 191);
			this->table1->TabIndex = 3;
			this->table1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MyForm2::table1_CellContentClick);
			// 
			// CheckBox
			// 
			this->CheckBox->HeaderText = L"�������";
			this->CheckBox->MinimumWidth = 6;
			this->CheckBox->Name = L"CheckBox";
			this->CheckBox->Width = 125;
			// 
			// name
			// 
			this->name->HeaderText = L"���";
			this->name->MinimumWidth = 6;
			this->name->Name = L"name";
			this->name->Width = 125;
			// 
			// surname
			// 
			this->surname->HeaderText = L"�������";
			this->surname->MinimumWidth = 6;
			this->surname->Name = L"surname";
			this->surname->Width = 125;
			// 
			// height
			// 
			this->height->HeaderText = L"����";
			this->height->MinimumWidth = 6;
			this->height->Name = L"height";
			this->height->Width = 125;
			// 
			// weight
			// 
			this->weight->HeaderText = L"���";
			this->weight->MinimumWidth = 6;
			this->weight->Name = L"weight";
			this->weight->Width = 125;
			// 
			// rate
			// 
			this->rate->HeaderText = L"�������";
			this->rate->MinimumWidth = 6;
			this->rate->Name = L"rate";
			this->rate->Width = 125;
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->clear);
			this->tabPage2->Controls->Add(this->statka);
			this->tabPage2->Controls->Add(this->button9);
			this->tabPage2->Controls->Add(this->button10);
			this->tabPage2->Controls->Add(this->button11);
			this->tabPage2->Controls->Add(this->table2);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage2->Size = System::Drawing::Size(759, 385);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"�����";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// clear
			// 
			this->clear->Location = System::Drawing::Point(561, 198);
			this->clear->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->clear->Name = L"clear";
			this->clear->Size = System::Drawing::Size(83, 24);
			this->clear->TabIndex = 12;
			this->clear->Text = L"�������";
			this->clear->UseVisualStyleBackColor = true;
			this->clear->Click += gcnew System::EventHandler(this, &MyForm2::clear_Click);
			// 
			// statka
			// 
			this->statka->Location = System::Drawing::Point(561, 169);
			this->statka->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->statka->Name = L"statka";
			this->statka->Size = System::Drawing::Size(83, 24);
			this->statka->TabIndex = 11;
			this->statka->Text = L"����������";
			this->statka->UseVisualStyleBackColor = true;
			this->statka->Click += gcnew System::EventHandler(this, &MyForm2::statka_Click);
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(561, 140);
			this->button9->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(83, 24);
			this->button9->TabIndex = 9;
			this->button9->Text = L"��������";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm2::button9_Click);
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(561, 110);
			this->button10->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(83, 24);
			this->button10->TabIndex = 8;
			this->button10->Text = L"������";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm2::button10_Click);
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(561, 81);
			this->button11->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(83, 24);
			this->button11->TabIndex = 7;
			this->button11->Text = L"�������";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm2::button11_Click);
			// 
			// table2
			// 
			this->table2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->table2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(4) {
				this->CheckBox1, this->team1,
					this->result, this->team2
			});
			this->table2->Location = System::Drawing::Point(20, 81);
			this->table2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->table2->Name = L"table2";
			this->table2->RowHeadersWidth = 51;
			this->table2->RowTemplate->Height = 24;
			this->table2->Size = System::Drawing::Size(513, 142);
			this->table2->TabIndex = 0;
			this->table2->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &MyForm2::dataGridView1_CellContentClick);
			// 
			// CheckBox1
			// 
			this->CheckBox1->HeaderText = L"�������";
			this->CheckBox1->MinimumWidth = 6;
			this->CheckBox1->Name = L"CheckBox1";
			this->CheckBox1->Resizable = System::Windows::Forms::DataGridViewTriState::True;
			this->CheckBox1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::Automatic;
			this->CheckBox1->Width = 125;
			// 
			// team1
			// 
			this->team1->HeaderText = L"�������1";
			this->team1->MinimumWidth = 6;
			this->team1->Name = L"team1";
			this->team1->Width = 125;
			// 
			// result
			// 
			this->result->HeaderText = L"����";
			this->result->MinimumWidth = 6;
			this->result->Name = L"result";
			this->result->Width = 125;
			// 
			// team2
			// 
			this->team2->HeaderText = L"�������2";
			this->team2->MinimumWidth = 6;
			this->team2->Name = L"team2";
			this->team2->Width = 125;
			// 
			// tabPage3
			// 
			this->tabPage3->Controls->Add(this->eagles);
			this->tabPage3->Controls->Add(this->pic2);
			this->tabPage3->Controls->Add(this->pic1);
			this->tabPage3->Controls->Add(this->pic3);
			this->tabPage3->Controls->Add(this->button16);
			this->tabPage3->Controls->Add(this->picture1);
			this->tabPage3->Controls->Add(this->picture2);
			this->tabPage3->Controls->Add(this->picture3);
			this->tabPage3->Location = System::Drawing::Point(4, 22);
			this->tabPage3->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Size = System::Drawing::Size(759, 385);
			this->tabPage3->TabIndex = 2;
			this->tabPage3->Text = L"������";
			this->tabPage3->UseVisualStyleBackColor = true;
			this->tabPage3->Click += gcnew System::EventHandler(this, &MyForm2::tabPage3_Click);
			// 
			// eagles
			// 
			this->eagles->AutoSize = true;
			this->eagles->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->eagles->Location = System::Drawing::Point(327, 12);
			this->eagles->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->eagles->Name = L"eagles";
			this->eagles->Size = System::Drawing::Size(64, 20);
			this->eagles->TabIndex = 8;
			this->eagles->Text = L"Eagles";
			// 
			// pic2
			// 
			this->pic2->AutoSize = true;
			this->pic2->Location = System::Drawing::Point(495, 292);
			this->pic2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->pic2->Name = L"pic2";
			this->pic2->Size = System::Drawing::Size(0, 13);
			this->pic2->TabIndex = 7;
			// 
			// pic1
			// 
			this->pic1->AutoSize = true;
			this->pic1->Location = System::Drawing::Point(270, 359);
			this->pic1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->pic1->Name = L"pic1";
			this->pic1->Size = System::Drawing::Size(0, 13);
			this->pic1->TabIndex = 6;
			// 
			// pic3
			// 
			this->pic3->AutoSize = true;
			this->pic3->Location = System::Drawing::Point(13, 292);
			this->pic3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->pic3->Name = L"pic3";
			this->pic3->Size = System::Drawing::Size(0, 13);
			this->pic3->TabIndex = 5;
			this->pic3->Click += gcnew System::EventHandler(this, &MyForm2::label19_Click);
			// 
			// button16
			// 
			this->button16->Location = System::Drawing::Point(15, 12);
			this->button16->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(121, 19);
			this->button16->TabIndex = 4;
			this->button16->Text = L"��������� �������";
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &MyForm2::button16_Click);
			// 
			// picture1
			// 
			this->picture1->Location = System::Drawing::Point(236, 87);
			this->picture1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->picture1->Name = L"picture1";
			this->picture1->Size = System::Drawing::Size(250, 265);
			this->picture1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->picture1->TabIndex = 3;
			this->picture1->TabStop = false;
			// 
			// picture2
			// 
			this->picture2->Location = System::Drawing::Point(568, 143);
			this->picture2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->picture2->Name = L"picture2";
			this->picture2->Size = System::Drawing::Size(131, 130);
			this->picture2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->picture2->TabIndex = 2;
			this->picture2->TabStop = false;
			this->picture2->Click += gcnew System::EventHandler(this, &MyForm2::picture2_Click);
			// 
			// picture3
			// 
			this->picture3->ImageLocation = L"";
			this->picture3->Location = System::Drawing::Point(15, 154);
			this->picture3->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->picture3->Name = L"picture3";
			this->picture3->Size = System::Drawing::Size(121, 121);
			this->picture3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->picture3->TabIndex = 1;
			this->picture3->TabStop = false;
			this->picture3->Click += gcnew System::EventHandler(this, &MyForm2::picture3_Click);
			// 
			// tabPage4
			// 
			this->tabPage4->Controls->Add(this->label13);
			this->tabPage4->Controls->Add(this->button12);
			this->tabPage4->Controls->Add(this->someteam2);
			this->tabPage4->Controls->Add(this->someresult);
			this->tabPage4->Controls->Add(this->someteam1);
			this->tabPage4->Controls->Add(this->label16);
			this->tabPage4->Controls->Add(this->label17);
			this->tabPage4->Controls->Add(this->ok);
			this->tabPage4->Controls->Add(this->SomeRate);
			this->tabPage4->Controls->Add(this->SomeWeight);
			this->tabPage4->Controls->Add(this->SomeHeight);
			this->tabPage4->Controls->Add(this->SomeSurname);
			this->tabPage4->Controls->Add(this->SomeName);
			this->tabPage4->Controls->Add(this->label5);
			this->tabPage4->Controls->Add(this->label4);
			this->tabPage4->Controls->Add(this->label3);
			this->tabPage4->Controls->Add(this->label2);
			this->tabPage4->Controls->Add(this->label1);
			this->tabPage4->Location = System::Drawing::Point(4, 22);
			this->tabPage4->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage4->Name = L"tabPage4";
			this->tabPage4->Size = System::Drawing::Size(759, 385);
			this->tabPage4->TabIndex = 2;
			this->tabPage4->Text = L"����������";
			this->tabPage4->UseVisualStyleBackColor = true;
			this->tabPage4->Click += gcnew System::EventHandler(this, &MyForm2::tabPage4_Click);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(387, 144);
			this->label13->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(113, 13);
			this->label13->TabIndex = 23;
			this->label13->Text = L"�������� 2 �������";
			// 
			// button12
			// 
			this->button12->Location = System::Drawing::Point(506, 175);
			this->button12->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(120, 19);
			this->button12->TabIndex = 22;
			this->button12->Text = L"���������� ����";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &MyForm2::button12_Click);
			// 
			// someteam2
			// 
			this->someteam2->Location = System::Drawing::Point(506, 141);
			this->someteam2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someteam2->Name = L"someteam2";
			this->someteam2->Size = System::Drawing::Size(121, 20);
			this->someteam2->TabIndex = 19;
			// 
			// someresult
			// 
			this->someresult->Location = System::Drawing::Point(506, 110);
			this->someresult->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someresult->Name = L"someresult";
			this->someresult->Size = System::Drawing::Size(121, 20);
			this->someresult->TabIndex = 18;
			// 
			// someteam1
			// 
			this->someteam1->Location = System::Drawing::Point(506, 84);
			this->someteam1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someteam1->Name = L"someteam1";
			this->someteam1->Size = System::Drawing::Size(121, 20);
			this->someteam1->TabIndex = 17;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(458, 112);
			this->label16->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(30, 13);
			this->label16->TabIndex = 13;
			this->label16->Text = L"����";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(394, 84);
			this->label17->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(113, 13);
			this->label17->TabIndex = 12;
			this->label17->Text = L"�������� 1 �������";
			// 
			// ok
			// 
			this->ok->Location = System::Drawing::Point(82, 210);
			this->ok->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->ok->Name = L"ok";
			this->ok->Size = System::Drawing::Size(120, 19);
			this->ok->TabIndex = 11;
			this->ok->Text = L"���������� ������";
			this->ok->UseVisualStyleBackColor = true;
			this->ok->Click += gcnew System::EventHandler(this, &MyForm2::ok_Click);
			// 
			// SomeRate
			// 
			this->SomeRate->Location = System::Drawing::Point(82, 176);
			this->SomeRate->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->SomeRate->Name = L"SomeRate";
			this->SomeRate->Size = System::Drawing::Size(121, 20);
			this->SomeRate->TabIndex = 10;
			// 
			// SomeWeight
			// 
			this->SomeWeight->Location = System::Drawing::Point(82, 141);
			this->SomeWeight->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->SomeWeight->Name = L"SomeWeight";
			this->SomeWeight->Size = System::Drawing::Size(121, 20);
			this->SomeWeight->TabIndex = 9;
			this->SomeWeight->TextChanged += gcnew System::EventHandler(this, &MyForm2::SomeWeight_TextChanged);
			// 
			// SomeHeight
			// 
			this->SomeHeight->Location = System::Drawing::Point(82, 110);
			this->SomeHeight->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->SomeHeight->Name = L"SomeHeight";
			this->SomeHeight->Size = System::Drawing::Size(121, 20);
			this->SomeHeight->TabIndex = 8;
			this->SomeHeight->TextChanged += gcnew System::EventHandler(this, &MyForm2::SomeHeight_TextChanged);
			// 
			// SomeSurname
			// 
			this->SomeSurname->Location = System::Drawing::Point(82, 79);
			this->SomeSurname->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->SomeSurname->Name = L"SomeSurname";
			this->SomeSurname->Size = System::Drawing::Size(121, 20);
			this->SomeSurname->TabIndex = 7;
			// 
			// SomeName
			// 
			this->SomeName->Location = System::Drawing::Point(82, 53);
			this->SomeName->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->SomeName->Name = L"SomeName";
			this->SomeName->Size = System::Drawing::Size(121, 20);
			this->SomeName->TabIndex = 6;
			this->SomeName->TextChanged += gcnew System::EventHandler(this, &MyForm2::textBox1_TextChanged);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(22, 176);
			this->label5->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(48, 13);
			this->label5->TabIndex = 5;
			this->label5->Text = L"�������";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(22, 141);
			this->label4->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(26, 13);
			this->label4->TabIndex = 4;
			this->label4->Text = L"���";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(20, 110);
			this->label3->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(31, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"����";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(20, 83);
			this->label2->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(56, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"�������";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(20, 53);
			this->label1->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(29, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"���";
			// 
			// tabPage5
			// 
			this->tabPage5->Controls->Add(this->button13);
			this->tabPage5->Controls->Add(this->button14);
			this->tabPage5->Controls->Add(this->button15);
			this->tabPage5->Controls->Add(this->label14);
			this->tabPage5->Controls->Add(this->someteam21);
			this->tabPage5->Controls->Add(this->someresult1);
			this->tabPage5->Controls->Add(this->someteam11);
			this->tabPage5->Controls->Add(this->label15);
			this->tabPage5->Controls->Add(this->label18);
			this->tabPage5->Controls->Add(this->button4);
			this->tabPage5->Controls->Add(this->button3);
			this->tabPage5->Controls->Add(this->button2);
			this->tabPage5->Controls->Add(this->rate2);
			this->tabPage5->Controls->Add(this->weight2);
			this->tabPage5->Controls->Add(this->height2);
			this->tabPage5->Controls->Add(this->surname2);
			this->tabPage5->Controls->Add(this->name2);
			this->tabPage5->Controls->Add(this->label6);
			this->tabPage5->Controls->Add(this->label7);
			this->tabPage5->Controls->Add(this->label8);
			this->tabPage5->Controls->Add(this->label9);
			this->tabPage5->Controls->Add(this->label10);
			this->tabPage5->Location = System::Drawing::Point(4, 22);
			this->tabPage5->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->tabPage5->Name = L"tabPage5";
			this->tabPage5->Size = System::Drawing::Size(759, 385);
			this->tabPage5->TabIndex = 3;
			this->tabPage5->Text = L"��������������";
			this->tabPage5->UseVisualStyleBackColor = true;
			this->tabPage5->Click += gcnew System::EventHandler(this, &MyForm2::tabPage5_Click_1);
			// 
			// button13
			// 
			this->button13->Location = System::Drawing::Point(483, 236);
			this->button13->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(66, 19);
			this->button13->TabIndex = 33;
			this->button13->Text = L"��������";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm2::button13_Click);
			// 
			// button14
			// 
			this->button14->Location = System::Drawing::Point(564, 236);
			this->button14->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(66, 19);
			this->button14->TabIndex = 32;
			this->button14->Text = L"������";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm2::button14_Click);
			// 
			// button15
			// 
			this->button15->Location = System::Drawing::Point(399, 236);
			this->button15->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(66, 19);
			this->button15->TabIndex = 31;
			this->button15->Text = L"�����";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm2::button15_Click);
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(351, 192);
			this->label14->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(113, 13);
			this->label14->TabIndex = 30;
			this->label14->Text = L"�������� 2 �������";
			// 
			// someteam21
			// 
			this->someteam21->Location = System::Drawing::Point(464, 192);
			this->someteam21->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someteam21->Name = L"someteam21";
			this->someteam21->Size = System::Drawing::Size(121, 20);
			this->someteam21->TabIndex = 29;
			// 
			// someresult1
			// 
			this->someresult1->Location = System::Drawing::Point(464, 161);
			this->someresult1->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someresult1->Name = L"someresult1";
			this->someresult1->Size = System::Drawing::Size(121, 20);
			this->someresult1->TabIndex = 28;
			// 
			// someteam11
			// 
			this->someteam11->Location = System::Drawing::Point(464, 135);
			this->someteam11->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->someteam11->Name = L"someteam11";
			this->someteam11->Size = System::Drawing::Size(121, 20);
			this->someteam11->TabIndex = 27;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(416, 163);
			this->label15->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(30, 13);
			this->label15->TabIndex = 26;
			this->label15->Text = L"����";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(351, 135);
			this->label18->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(113, 13);
			this->label18->TabIndex = 25;
			this->label18->Text = L"�������� 1 �������";
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(114, 262);
			this->button4->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(66, 19);
			this->button4->TabIndex = 24;
			this->button4->Text = L"��������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm2::button4_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(195, 262);
			this->button3->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(66, 19);
			this->button3->TabIndex = 23;
			this->button3->Text = L"������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm2::button3_Click_1);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(30, 262);
			this->button2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(66, 19);
			this->button2->TabIndex = 22;
			this->button2->Text = L"�����";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm2::button2_Click_1);
			// 
			// rate2
			// 
			this->rate2->Location = System::Drawing::Point(88, 228);
			this->rate2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->rate2->Name = L"rate2";
			this->rate2->Size = System::Drawing::Size(121, 20);
			this->rate2->TabIndex = 21;
			// 
			// weight2
			// 
			this->weight2->Location = System::Drawing::Point(88, 193);
			this->weight2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->weight2->Name = L"weight2";
			this->weight2->Size = System::Drawing::Size(121, 20);
			this->weight2->TabIndex = 20;
			// 
			// height2
			// 
			this->height2->Location = System::Drawing::Point(88, 161);
			this->height2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->height2->Name = L"height2";
			this->height2->Size = System::Drawing::Size(121, 20);
			this->height2->TabIndex = 19;
			this->height2->TextChanged += gcnew System::EventHandler(this, &MyForm2::height2_TextChanged);
			// 
			// surname2
			// 
			this->surname2->Location = System::Drawing::Point(88, 130);
			this->surname2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->surname2->Name = L"surname2";
			this->surname2->Size = System::Drawing::Size(121, 20);
			this->surname2->TabIndex = 18;
			this->surname2->TextChanged += gcnew System::EventHandler(this, &MyForm2::surname2_TextChanged);
			// 
			// name2
			// 
			this->name2->Location = System::Drawing::Point(88, 104);
			this->name2->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->name2->Name = L"name2";
			this->name2->Size = System::Drawing::Size(121, 20);
			this->name2->TabIndex = 17;
			this->name2->TextChanged += gcnew System::EventHandler(this, &MyForm2::textBox5_TextChanged);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(28, 228);
			this->label6->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(48, 13);
			this->label6->TabIndex = 16;
			this->label6->Text = L"�������";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(28, 193);
			this->label7->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(26, 13);
			this->label7->TabIndex = 15;
			this->label7->Text = L"���";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(26, 161);
			this->label8->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(31, 13);
			this->label8->TabIndex = 14;
			this->label8->Text = L"����";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(26, 134);
			this->label9->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(56, 13);
			this->label9->TabIndex = 13;
			this->label9->Text = L"�������";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(26, 104);
			this->label10->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(29, 13);
			this->label10->TabIndex = 12;
			this->label10->Text = L"���";
			// 
			// MyForm2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(727, 401);
			this->Controls->Add(this->tabControl1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(2, 2, 2, 2);
			this->Name = L"MyForm2";
			this->Text = L"team";
			this->Load += gcnew System::EventHandler(this, &MyForm2::MyForm2_Load);
			this->tabControl1->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->table1))->EndInit();
			this->tabPage2->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->table2))->EndInit();
			this->tabPage3->ResumeLayout(false);
			this->tabPage3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture3))->EndInit();
			this->tabPage4->ResumeLayout(false);
			this->tabPage4->PerformLayout();
			this->tabPage5->ResumeLayout(false);
			this->tabPage5->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
		   //hjgh
	public: System::Void table1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
	}
		  //�������� (������� �� add)
	private: System::Void MyForm2_Load(System::Object^ sender, System::EventArgs^ e) {
	}
		   bool check(String^ s1, String^ s2, String^ s3, String^ s4, String^ s5) {
			   bool f1 = false;
			   bool f2 = false;
			   bool f3 = false;
			   bool f4 = false;
			   bool f5 = false;
			   ////////////////////////////////////////
			   //////////////////////////////////////////////
			   if (Regex::IsMatch(s1,
				   "^[a-zA-Z�-��-�]+$"))
			   {
				   if (s1 != "") {
					   f1 = true;
				   }
			   }
			   if (Regex::IsMatch(s2,
				   "^[a-zA-Z�-��-�]+$"))
			   {
				   if (s2 != "") {
					   f2 = true;
				   }
			   }
			   //////////////////////////////////////////////////
			   Int32 ht = 0;
			   if (Regex::IsMatch(s3,
				   "^[0-9]+$") && s3 != "")
			   {
				   ht = System::Convert::ToInt32(s3);
				   if (ht > 100 && ht < 290) f3 = true;
			   }
			   ////////////////////////////////////////////////////
			   if (Regex::IsMatch(s4,
				   "^[0-9]+$") && s4 != "")
			   {
				   ht = System::Convert::ToInt32(s4);
				   if (ht > 40 && ht < 200) f4 = true;
			   }
			   ///////////////////////////////////////////////////////////////
			   if (Regex::IsMatch(s5,
				   "^[0-9]+$") && s5 != "")
			   {
				   ht = System::Convert::ToInt32(s5);
				   if (ht >= 0 && ht <= 100) f5 = true;
			   }
			   /////////////////////////////////////////////////////////////////
			   if (f1 == true && f2 == true && f3 == true && f4 == true && f5 == true) {
				   return true;
			   }
			   else {
				   return false;
			   }
		   }
		   //����������
	private: System::Void ok_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = SomeName->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		SomeName->Text = stroka;
		/////////////////////////////////////////////
		stroka = SomeSurname->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		SomeSurname->Text = stroka;
		////////////////////////////////////////////////
		stroka = SomeHeight->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		SomeHeight->Text = stroka;
		///////////////////////////////////////
		stroka = SomeWeight->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		SomeWeight->Text = stroka;
		/////////////////////////////////////////////
		stroka = SomeRate->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		SomeRate->Text = stroka;
		if (check(SomeName->Text, SomeSurname->Text, SomeHeight->Text, SomeWeight->Text, SomeRate->Text) == true) {
			table();
			MessageBox::Show("����� ������� �������� � ������� �������", "���������");
		}
		else {
			MessageBox::Show("������������ ������ �����\n���������", "���������");
		}
	}
		   //���������� �������
		   void fresh(Generic::List<Player^>^ list) {
			   table1->Rows->Clear();
			   table1->Refresh();
			   for (int h = 0; h < list->Count; h++) {
				   String^ li = list[h]->adding();
				   DataGridViewRow^ row = gcnew DataGridViewRow();
				   row->CreateCells(table1);
				   for (int i = 0; i < li->Split(L' ')->Length; i++)
					   row->Cells[i + 1]->Value = li->Split(L' ')[i];
				   table1->Rows->Add(row);
			   }
		   }
		   // ���������� � �������()
		   void table() {
			   Player^ my = gcnew  Player(SomeName->Text, SomeSurname->Text, SomeHeight->Text, SomeWeight->Text, SomeRate->Text);
			   list->Add(my);
			   int h = list->Count - 1;
			   String^ li = list[h]->adding();
			   DataGridViewRow^ row = gcnew DataGridViewRow();
			   row->CreateCells(table1);
			   for (int i = 0; i < li->Split(L' ')->Length; i++)
				   row->Cells[i + 1]->Value = li->Split(L' ')[i];
			   table1->Rows->Add(row);
		   }

	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	};
	private: System::Void SomeHeight_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void tabPage5_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label6_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox1_TextChanged_1(System::Object^ sender, System::EventArgs^ e) {

	}
	private: System::Void SomeWeight_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   //�������� ��������
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		for (int i = table1->Rows->Count - 1; i >= 0; i--) {
			if (System::Convert::ToBoolean(table1->Rows[i]->Cells[0]->Value) == true) {
				list->RemoveAt(i);
			}
		}
		fresh(list);
	}
	private: System::Void textBox5_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   int k = -1;
		   //�����
	private: System::Void button2_Click_1(System::Object^ sender, System::EventArgs^ e) {

		if (k == -1 || k == 0) {
			k = 1;
		}
		k--;
		if (list->Count != 0) {
			name2->Text = list[k]->getName();
			surname2->Text = list[k]->getSurname();
			height2->Text = list[k]->getHeight();
			weight2->Text = list[k]->getWeight();
			rate2->Text = list[k]->getRate();
		}
		else {
			name2->Text = "";
			surname2->Text = "";
			height2->Text = "";
			weight2->Text = "";
			rate2->Text = "";
		}
	}
		   //������
	private: System::Void button3_Click_1(System::Object^ sender, System::EventArgs^ e) {
		if (k == list->Count - 1) {
			k = list->Count - 2;
		}
		k++;
		if (list->Count != 0) {
			name2->Text = list[k]->getName();
			surname2->Text = list[k]->getSurname();
			height2->Text = list[k]->getHeight();
			weight2->Text = list[k]->getWeight();
			rate2->Text = list[k]->getRate();
		}
		else {
			name2->Text = "";
			surname2->Text = "";
			height2->Text = "";
			weight2->Text = "";
			rate2->Text = "";
		}
	}
		   //��������(�����)
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = name2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		name2->Text = stroka;
		/////////////////////////////////////////////
		stroka = surname2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		surname2->Text = stroka;
		////////////////////////////////////////////////
		stroka = height2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		height2->Text = stroka;
		///////////////////////////////////////
		stroka = weight2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		weight2->Text = stroka;
		/////////////////////////////////////////////
		stroka = rate2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		rate2->Text = stroka;
		if (check(name2->Text, surname2->Text, height2->Text, weight2->Text, rate2->Text) == true) {
			Player^ me = gcnew  Player(name2->Text, surname2->Text, height2->Text, weight2->Text, rate2->Text);
			list->RemoveAt(k);
			list->Insert(k, me);
			fresh(list);
			MessageBox::Show("�������������� ����������� �������", "���������");
		}
		else {
			MessageBox::Show("������������ ������ �����\n���������", "���������");
		}
	}
	private: System::Void height2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void surname2_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   //���������� � �������
		   void load() {

			   cli::array<String^>^ lines = File::ReadAllLines("F:\\c++\\kurse\\players.txt");
			   for each (String ^ str in lines)
			   {
				   cli::array<String^>^ m = gcnew cli::array<String^>(5);
				   DataGridViewRow^ row = gcnew DataGridViewRow();
				   for (int i = 0; i < str->Split(L' ')->Length; i++) {
					   m[i] = str->Split(L' ')[i];
				   }
				   Player^ me = gcnew  Player(m[0], m[1], m[2], m[3], m[4]);
				   list->Add(me);
			   }
			   fresh(list);
		   }
		   //������� �� ����� � �������
	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
		load();
	}
		   //������ � ����
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
		System::IO::StreamWriter^ fp = gcnew System::IO::StreamWriter("F:\\c++\\kurse\\playersw.txt", true);
		for (int i = 0; i < list->Count; i++) {
			fp->WriteLine(list[i]->adding());
		}
		fp->Close();
		MessageBox::Show("������ �������� � ����", "���������");
	}
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   //��� ����������
		   void sort(Generic::List<Player^>^ list) {
			   list->Clear();
			   for (int i = 0; i < table1->Rows->Count - 1; i++) {
				   String^ d1 = table1->Rows[i]->Cells[1]->Value->ToString();
				   String^ d2 = table1->Rows[i]->Cells[2]->Value->ToString();
				   String^ d3 = table1->Rows[i]->Cells[3]->Value->ToString();
				   String^ d4 = table1->Rows[i]->Cells[4]->Value->ToString();
				   String^ d5 = table1->Rows[i]->Cells[5]->Value->ToString();
				   Player^ me = gcnew  Player(d1, d2, d3, d4, d5);
				   list->Add(me);
			   }
		   }
		   //����������
	private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
		if (comboBox1->SelectedItem == "���") {
			table1->Sort(table1->Columns[1], ListSortDirection::Ascending);
			sort(list);
		}
		if (comboBox1->SelectedItem == "�������") {
			table1->Sort(table1->Columns[2], ListSortDirection::Ascending);
			sort(list);
		}
		if (comboBox1->SelectedItem == "����") {
			table1->Sort(table1->Columns[3], ListSortDirection::Ascending);
			sort(list);
		}
		if (comboBox1->SelectedItem == "���") {
			table1->Sort(table1->Columns[4], ListSortDirection::Ascending);
			sort(list);
		}
		if (comboBox1->SelectedItem == "�������") {
			table1->Sort(table1->Columns[5], ListSortDirection::Ascending);
			sort(list);
		}
	}
	private: System::Void comboBox2_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	}
		   bool checkpoisk(String^ s) {
			   if (Regex::IsMatch(s,
				   "^[a-zA-Z�-��-�]+$"))
			   {
				   if (s != "") {
					   return true;
				   }
			   }
			   return false;
		   }

		   //����� �� ����� � �������
	private: System::Void poisk_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = poisk1->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		poisk1->Text = stroka;
		if (comboBox2->SelectedItem == "���") {
			if (checkpoisk(poisk1->Text) == true) {
				for (int i = table1->Rows->Count - 2; i > -1; i--) {
					if (String::Compare(table1->Rows[i]->Cells[1]->Value->ToString(), poisk1->Text) == 0) {
						continue;
					}
					else {
						list->RemoveAt(i);
					}
				}
				fresh(list);
			}
			else {
				MessageBox::Show("��������� ��������� ������", "���������");
			}
		}
		if (comboBox2->SelectedItem == "�������") {
			if (checkpoisk(poisk1->Text) == true) {
				for (int i = table1->Rows->Count - 2; i > -1; i--) {
					if (String::Compare(table1->Rows[i]->Cells[2]->Value->ToString(), poisk1->Text) == 0) {
						continue;
					}
					else {
						list->RemoveAt(i);
					}
				}
				fresh(list);
			}
			else {
				MessageBox::Show("��������� ��������� ������", "���������");
			}
		}
	}
		   bool number(String^ s) {
			   if (Regex::IsMatch(s,
				   "^(-)?[0-9]+$") && s != "")
			   {
				   return true;
			   }
			   return false;
		   }
		   //����� (�� - ��)
	private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = from->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		from->Text = stroka;
		stroka = to->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		to->Text = stroka;
		if (comboBox3->SelectedItem == "����") {
			if (number(from->Text) == true && number(to->Text) == true) {
				Int32 f = System::Convert::ToInt32(from->Text);
				Int32 t = System::Convert::ToInt32(to->Text);
				Int32 n = 0;
				for (int i = table1->Rows->Count - 2; i > -1; i--) {
					n = System::Convert::ToInt32(table1->Rows[i]->Cells[3]->Value->ToString());
					if (n >= f && n <= t) {
						continue;
					}
					else {
						list->RemoveAt(i);
					}
				}
				fresh(list);
			}
			else {
				MessageBox::Show("��������� ��������� ������", "���������");
			}
		}
		if (comboBox3->SelectedItem == "���") {
			if (number(from->Text) == true && number(to->Text) == true) {
				Int32 f = System::Convert::ToInt32(from->Text);
				Int32 t = System::Convert::ToInt32(to->Text);
				Int32 n = 0;
				for (int i = table1->Rows->Count - 2; i > -1; i--) {
					n = System::Convert::ToInt32(table1->Rows[i]->Cells[4]->Value->ToString());
					if (n >= f && n <= t) {
						continue;
					}
					else {
						list->RemoveAt(i);
					}
				}
				fresh(list);
			}
			else {
				MessageBox::Show("��������� ��������� ������", "���������");
			}
		}
		if (comboBox3->SelectedItem == "�������") {
			if (number(from->Text) == true && number(to->Text) == true) {
				Int32 f = System::Convert::ToInt32(from->Text);
				Int32 t = System::Convert::ToInt32(to->Text);
				Int32 n = 0;
				for (int i = table1->Rows->Count - 2; i > -1; i--) {
					n = System::Convert::ToInt32(table1->Rows[i]->Cells[5]->Value->ToString());
					if (n >= f && n <= t) {
						continue;
					}
					else {
						list->RemoveAt(i);
					}
				}
				fresh(list);
			}
			else {
				MessageBox::Show("��������� ��������� ������", "���������");
			}
		}
	}
	private: System::Void textBox1_TextChanged_2(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
	}
	private: System::Void tabPage4_Click(System::Object^ sender, System::EventArgs^ e) {
	}
		   //���������� ������� �����
		   void fresh2(Generic::List<Play^>^ list1) {
			   table2->Rows->Clear();
			   table2->Refresh();
			   for (int h = 0; h < list1->Count; h++) {
				   String^ li = list1[h]->adding1();
				   DataGridViewRow^ row = gcnew DataGridViewRow();
				   row->CreateCells(table2);
				   for (int i = 0; i < li->Split(L' ')->Length; i++)
					   row->Cells[i + 1]->Value = li->Split(L' ')[i];
				   table2->Rows->Add(row);
			   }
		   }
		   // ���������� � ������� �����
		   void tabl() {
			   Play^ my = gcnew  Play(someteam1->Text, someresult->Text, someteam2->Text);
			   list1->Add(my);
			   int h = list1->Count - 1;
			   String^ li = list1[h]->adding1();
			   DataGridViewRow^ row = gcnew DataGridViewRow();
			   row->CreateCells(table2);
			   for (int i = 0; i < li->Split(L' ')->Length; i++)
				   row->Cells[i + 1]->Value = li->Split(L' ')[i];
			   table2->Rows->Add(row);
		   }
		   bool checkresult(String^ s) {
			   if (Regex::IsMatch(s,
				   "^[0-9]+:[0-9]+$") && s != "")
			   {
				   return true;
			   }
			   return false;
		   }
		   //���������� �����
	private: System::Void button12_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = someteam1->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someteam1->Text = stroka;
		stroka = someresult->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someresult->Text = stroka;
		stroka = someteam2->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someteam2->Text = stroka;
		if (checkpoisk(someteam1->Text) == true && checkpoisk(someteam2->Text) == true && checkresult(someresult->Text)) {
			tabl();
			MessageBox::Show("���� ������� ��������� � ������� ������", "���������");
		}
		else {
			MessageBox::Show("������������ ������ �����\n���������", "���������");
		}
	}
		   //�������� ������
	private: System::Void button11_Click(System::Object^ sender, System::EventArgs^ e) {
		for (int i = table2->Rows->Count - 1; i >= 0; i--) {
			if (System::Convert::ToBoolean(table2->Rows[i]->Cells[0]->Value) == true) {
				list1->RemoveAt(i);
			}
		}
		fresh2(list1);
	}
	private: System::Void tabPage5_Click_1(System::Object^ sender, System::EventArgs^ e) {
	}
		   int k1 = -1;
		   //�����(�����)
	private: System::Void button15_Click(System::Object^ sender, System::EventArgs^ e) {

		if (k1 == -1 || k1 == 0) {
			k1 = 1;
		}
		k1--;
		if (list1->Count != 0) {
			someteam11->Text = list1[k1]->getTeam1();
			someresult1->Text = list1[k1]->getResult();
			someteam21->Text = list1[k1]->getTeam2();
		}
		else {
			someteam11->Text = "";
			someresult1->Text = "";
			someteam21->Text = "";
		}
	}
		   //������(�����)
	private: System::Void button14_Click(System::Object^ sender, System::EventArgs^ e) {
		if (k1 == list1->Count - 1) {
			k1 = list1->Count - 2;
		}
		k1++;
		if (list1->Count != 0) {
			someteam11->Text = list1[k1]->getTeam1();
			someresult1->Text = list1[k1]->getResult();
			someteam21->Text = list1[k1]->getTeam2();
		}
		else {
			someteam11->Text = "";
			someresult1->Text = "";
			someteam21->Text = "";
		}
	}
		   //��������
	private: System::Void button13_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ stroka = someteam11->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someteam11->Text = stroka;
		/////////////////////////////////////////////
		stroka = someresult1->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someresult1->Text = stroka;
		////////////////////////////////////////////////
		stroka = someteam21->Text;
		stroka = Regex::Replace(stroka, "\\s+", "");
		someteam21->Text = stroka;
		///////////////////////////////////////
		if (checkpoisk(someteam11->Text) == true && checkpoisk(someteam21->Text) == true && checkresult(someresult1->Text)) {
			Play^ me = gcnew  Play(someteam11->Text, someresult1->Text, someteam21->Text);
			list1->RemoveAt(k1);
			list1->Insert(k1, me);
			fresh2(list1);
			MessageBox::Show("�������������� ����������� �������", "���������");
		}
		else {
			MessageBox::Show("������������ ������ �����\n���������", "���������");
		}
	}
		   //���������� � �������
		   void load1() {

			   cli::array<String^>^ lines1 = File::ReadAllLines("F:\\c++\\kurse\\play.txt");
			   for each (String ^ str in lines1)
			   {
				   cli::array<String^>^ m1 = gcnew cli::array<String^>(3);
				   cli::array<String^>^ m2 = gcnew cli::array<String^>(3);
				   DataGridViewRow^ row = gcnew DataGridViewRow();
				   for (int i = 0; i < str->Split(L' ')->Length; i++) {
					   m1[i] = str->Split(L' ')[i];
				   }
				   Play^ me = gcnew  Play(m1[0], m1[1], m1[2]);
				   list1->Add(me);
			   }
			   fresh2(list1);
		   }
		   //������ ������ �� ����� � �������(�����)
	private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
		load1();
	}
		   //������ ������ � ����(�����)
	private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
		System::IO::StreamWriter^ fp = gcnew System::IO::StreamWriter("F:\\c++\\kurse\\playw.txt", true);
		for (int i = 0; i < list1->Count; i++) {
			fp->WriteLine(list1[i]->adding1());
		}
		fp->Close();
		MessageBox::Show("������ �������� � ����", "���������");
	}
		   //��������� �������
	private: System::Void button16_Click(System::Object^ sender, System::EventArgs^ e) {
		int kol = 0; //������ ������ � ������
		Int32 h1 = 0;
		Int32 h2 = 0;
		bool fl = false;
		int count = 0; //����� ������
		int all = 0; //��� ����������� �����
		int prize = 0;//���������� ������
		delete picture3->Image;
		picture3->Image = nullptr;
		delete picture2->Image;
		picture2->Image = nullptr;
		delete picture1->Image;
		picture1->Image = nullptr;
		pic3->Text = "";
		pic2->Text = "";
		pic1->Text = "";
		cli::array<String^>^ md = gcnew cli::array<String^>(2);
		for (int i = 0; i < list1->Count; i++) {
			for (int j = 0; j < list1[i]->getResult()->Split(L':')->Length; j++) {
				md[j] = list1[i]->getResult()->Split(L':')[j];
			}
				h1 = System::Convert::ToInt32(md[0]);
				h2 = System::Convert::ToInt32(md[1]);
			
			if ((h1 > h2 && String::Compare(list1[i]->getTeam1(), eagles->Text) == 0) || (h1 < h2 && String::Compare(list1[i]->getTeam2(), eagles->Text) == 0)) { kol++; prize++; }
			if (String::Compare(list1[i]->getTeam1(), eagles->Text) == 0 || String::Compare(list1[i]->getTeam2(), eagles->Text) == 0) {
				all++;
			}
		}
		
		for (int i = 0; i < list1->Count; i++) {
			for (int j = 0; j < list1[i]->getResult()->Split(L':')->Length; j++) {
				md[j] = list1[i]->getResult()->Split(L':')[j];
			}
			h1 = System::Convert::ToInt32(md[0]);
			h2 = System::Convert::ToInt32(md[1]);
			if ((h1 > h2 && String::Compare(list1[i]->getTeam1(), eagles->Text) == 0) || (h1 < h2 && String::Compare(list1[i]->getTeam2(), eagles->Text) == 0)) {
				count++;
			}
			if ((h1 < h2 && String::Compare(list1[i]->getTeam1(), eagles->Text) == 0) || (h1 > h2 && String::Compare(list1[i]->getTeam2(), eagles->Text) == 0)) {
				count = 0;
			}
			if (count >= 3) break;
		}
		if (kol >= 3) {
			picture3->Image = Image::FromFile("F:\\c++\\kurse\\pictures\\picture3.png");
			pic3->Text = "�� ������ � �� ����� ��� 3 ������";
			System::Media::SoundPlayer^ player1 = gcnew System::Media::SoundPlayer();
			player1->SoundLocation = "F:\\c++\\kurse\\win1.wav";
			player1->Load();
			player1->PlaySync();
		}
		if (count >= 3) {
			picture2->Image = Image::FromFile("F:\\c++\\kurse\\pictures\\picture2.png");
			pic2->Text = "�� ������ � �� ����� ��� 3 ������ ������";
		}
		if (prize == all && all!=0) {
			picture1->Image = Image::FromFile("F:\\c++\\kurse\\pictures\\picture1.png");
			pic1->Text = "�� ���������� ������";
			
		}
		if (kol < 3) {
			System::Media::SoundPlayer^ player = gcnew System::Media::SoundPlayer();
			player->SoundLocation = "F:\\c++\\kurse\\bad.wav";
			player->Load();
			player->PlaySync();
			MessageBox::Show("� ����� ������� ��� �������", "���������");
		}
	}
	private: System::Void label19_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void picture3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void tabPage3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void picture2_Click(System::Object^ sender, System::EventArgs^ e) {
}
	   //����������
private: System::Void statka_Click(System::Object^ sender, System::EventArgs^ e) {
	Int32 h11 = 0;
	Int32 h22 = 0;
	int win = 0;
	int bad = 0;
	int al = 0;
	MyForm3^ f3 = gcnew MyForm3();
	f3->Show();
	cli::array<String^>^ md = gcnew cli::array<String^>(2);
	for (int i = 0; i < list1->Count; i++) {
		for (int j = 0; j < list1[i]->getResult()->Split(L':')->Length; j++) {
			md[j] = list1[i]->getResult()->Split(L':')[j];
		}
		if (String::Compare(list1[i]->getTeam1(), eagles->Text) == 0) {
			h11 = System::Convert::ToInt32(md[0]);
			h22 = System::Convert::ToInt32(md[1]);
			al++;
			if (h11 > h22) win++;
			if (h11 < h22) bad++;
		}
		if (String::Compare(list1[i]->getTeam2(), eagles->Text) == 0) {
			h11 = System::Convert::ToInt32(md[0]);
			h22 = System::Convert::ToInt32(md[1]);
			al++;
			if (h11 < h22) win++;
			if (h11 > h22) bad++;
		}

	}
	System::IO::StreamWriter^ fp = gcnew System::IO::StreamWriter("F:\\c++\\kurse\\stat.txt");
	fp->WriteLine(Convert::ToString(win));
	fp->WriteLine(Convert::ToString(bad));
	fp->WriteLine(Convert::ToString(al));
	fp->Close();
}
	   //�������
private: System::Void clear_Click(System::Object^ sender, System::EventArgs^ e) {
	list1->Clear();
	table2->Rows->Clear();
	table2->Refresh();
}
private: System::Void button17_Click(System::Object^ sender, System::EventArgs^ e) {
	list->Clear();
	table1->Rows->Clear();
	table1->Refresh();
}
private: System::Void tabPage1_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
}
