#pragma once
using namespace System;
public ref class Play {
	String^ team1;
	String^ result;
	String^ team2;
public:
	Play(String^ name11, String^ result1, String^ name21) {
		team1 = name11;
		result = result1;
		team2 = name21;
	}
	void setTeam1(String^ name11);
	String^ getTeam1();

	void setResult(String^ result1);
	String^ getResult();

	void setTeam2(String^ name21);
	String^ getTeam2();

	String^ adding1();
};