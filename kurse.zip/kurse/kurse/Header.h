#pragma once
#include <list>
#include <algorithm>
using namespace System;
public ref class Player {
	String^ name;
	String^ surname;
	String^ height;
	String^ weight;
	String^ rate;
public:
	Player(String^ name1, String^ surname1, String^ height1, String^ weight1, String^ rate1) {
		name = name1;
		surname = surname1;
		height = height1;
		weight = weight1;
		rate = rate1;
	}
	void setName(String^ name2);
	String^ getName();

	void setSurname(String^ surname2);
	String^ getSurname();

	void setWeight(String^ weight2);
	String^ getWeight();

	void setHeight(String^ height2);
	String^ getHeight();

	void setRate(String^ rate2);
	String^ getRate();

	String^ adding();

	//void setFlag(bool flag2);
	//bool getFlag();
};
