#include "Header1.h"

void Play::setTeam1(String^ name11)
{
	team1 = name11;
}

String^ Play::getTeam1()
{
	return team1;
}

void Play::setResult(String^ result1)
{
	result = result1;
}

String^ Play::getResult()
{
	return result;
}

void Play::setTeam2(String^ name21)
{
	team2 = name21;
}

String^ Play::getTeam2()
{
	return team2;
}

String^ Play::adding1()
{
	return (team1 + " " + result + " " + team2);
}


