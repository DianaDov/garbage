#define _CRT_SECURE_NO_WARNINGS
#include "MyForm.h"
#include <iostream>
#include <stdio.h>
#include <locale.h>
#include <string>
using namespace System;
using namespace System::Windows::Forms;
using namespace std;



[STAThread]
void main() {
	setlocale(LC_ALL, ".1251");
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	kurse::MyForm form;
	Application::Run(% form);
}


